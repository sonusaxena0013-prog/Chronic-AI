import { useEffect, useRef, useState } from "react";
import {
  FiSend,
  FiPaperclip,
  FiMic,
  FiImage,
  FiX,
} from "react-icons/fi";

export default function PromptBar({
  onSend,
  onStop,
  isStreaming,

  onFileSelect,
  attachedFile,
  removeFile,

  onImageSelect,
  attachedImage,
  removeImage,
}) {
  const [message, setMessage] = useState("");
  const [isListening, setIsListening] = useState(false);

  const recognitionRef = useRef(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);

  /* =========================================
     AUTO RESIZE
  ========================================= */

  function autoResize() {
    if (!textareaRef.current) return;

    textareaRef.current.style.height = "auto";

    textareaRef.current.style.height =
      `${textareaRef.current.scrollHeight}px`;
  }

  /* =========================================
     SPEECH RECOGNITION
  ========================================= */

  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition ||
      window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn("Speech Recognition not supported");
      return;
    }

    const recognition = new SpeechRecognition();

    recognition.lang = "en-IN";
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.onerror = (e) => {
      console.error("Speech Error:", e);
      setIsListening(false);
    };

    recognition.onresult = (event) => {
      let transcript = "";

      for (
        let i = event.resultIndex;
        i < event.results.length;
        i++
      ) {
        transcript += event.results[i][0].transcript;
      }

      setMessage(transcript);

      setTimeout(() => {
        autoResize();
      }, 0);

      const last =
        event.results[event.results.length - 1];

      if (last.isFinal) {
        const finalText = transcript.trim();

        if (finalText && !isStreaming) {
          sendText(finalText);
        }
      }
    };

    recognitionRef.current = recognition;

    return () => {
      recognition.stop();
      recognitionRef.current = null;
    };
  }, [isStreaming]);

  /* =========================================
     FILE
  ========================================= */

  function chooseFile() {
    fileInputRef.current?.click();
  }

  function chooseImage() {
    imageInputRef.current?.click();
  }

  function handleFile(e) {
    const file = e.target.files?.[0];

    if (!file) return;

    onFileSelect?.(file);

    e.target.value = "";
  }

  function handleImage(e) {
    const file = e.target.files?.[0];

    if (!file) return;

    onImageSelect?.(file);

    e.target.value = "";
  }

  /* =========================================
     INPUT
  ========================================= */

  function handleChange(e) {
    setMessage(e.target.value);

    setTimeout(() => {
      autoResize();
    }, 0);
  }

  /* =========================================
     SEND MESSAGE
  ========================================= */

  async function sendText(text) {
    const cleanText = text.trim();

    if (!cleanText) return;

    if (isStreaming) return;

    try {
      /*
        IMPORTANT:
        Send first.
        Input stays mounted.
      */
      await onSend(cleanText);

      /*
        Clear only after onSend has started/finished.
        Prompt bar itself NEVER disappears.
      */
      setMessage("");

      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    } catch (error) {
      console.error("Send message error:", error);
    }
  }

  function sendMessage() {
    const text = message.trim();

    if (!text) return;

    sendText(text);
  }

  /* =========================================
     ENTER KEY
  ========================================= */

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();

      if (!isStreaming) {
        sendMessage();
      }
    }
  }

  /* =========================================
     VOICE
  ========================================= */

  function toggleVoice() {
    if (!recognitionRef.current) {
      alert(
        "Speech Recognition is not supported in this browser."
      );
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      return;
    }

    setMessage("");

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    recognitionRef.current.start();
  }

  /* =========================================
     RENDER
  ========================================= */

  return (
    <div className="promptWrapper">

      <div
        className={`promptContainer ${
          isStreaming ? "promptStreaming" : ""
        }`}
      >

        {/* FILE INPUT */}

        <input
          type="file"
          ref={fileInputRef}
          hidden
          accept=".pdf,.doc,.docx,.txt,.md"
          onChange={handleFile}
        />

        {/* IMAGE INPUT */}

        <input
          type="file"
          ref={imageInputRef}
          hidden
          accept="image/*"
          onChange={handleImage}
        />

        {/* ATTACH FILE */}

        <button
          className="toolBtn"
          type="button"
          onClick={chooseFile}
          aria-label="Attach file"
        >
          <FiPaperclip size={20} />
        </button>

        {/* ATTACH IMAGE */}

        <button
          className="toolBtn"
          type="button"
          onClick={chooseImage}
          aria-label="Attach image"
        >
          <FiImage size={20} />
        </button>

        {/* ATTACHED FILE */}

        {attachedFile && (
          <div className="attachedFile">

            <span>
              📄 {attachedFile.name}
            </span>

            <button
              className="removeFileBtn"
              type="button"
              onClick={removeFile}
              aria-label="Remove file"
            >
              <FiX />
            </button>

          </div>
        )}

        {/* ATTACHED IMAGE */}

        {attachedImage && (
          <div className="attachedFile">

            <img
              src={URL.createObjectURL(attachedImage)}
              alt="Preview"
              width={45}
              height={45}
              style={{
                objectFit: "cover",
                borderRadius: "8px",
                marginRight: "10px",
              }}
            />

            <span>
              {attachedImage.name}
            </span>

            <button
              className="removeFileBtn"
              type="button"
              onClick={removeImage}
              aria-label="Remove image"
            >
              <FiX />
            </button>

          </div>
        )}

        {/* TEXT AREA */}

        <textarea
          ref={textareaRef}
          rows={1}
          value={message}
          placeholder={
            isStreaming
              ? "Chronic AI is responding..."
              : "Message Chronic AI..."
          }
          onChange={handleChange}
          onKeyDown={handleKeyDown}
        />

        {/* MIC */}

        <button
          className={`toolBtn ${
            isListening ? "listening" : ""
          }`}
          type="button"
          aria-label="Voice Input"
          onClick={toggleVoice}
        >
          {isListening ? (
            "🔴"
          ) : (
            <FiMic size={20} />
          )}
        </button>

        {/* SEND / STOP */}

        {isStreaming ? (
          <button
            className="sendBtn stopBtn"
            type="button"
            onClick={onStop}
            aria-label="Stop Response"
          >
            ⏹
          </button>
        ) : (
          <button
            className="sendBtn"
            type="button"
            onClick={sendMessage}
            disabled={!message.trim()}
            aria-label="Send Message"
          >
            <FiSend size={20} />
          </button>
        )}

      </div>
    </div>
  );
}