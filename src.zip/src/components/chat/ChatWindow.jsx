import { useEffect, useRef, useState } from "react";

import MessageBubble from "./MessageBubble";
import TypingIndicator from "./TypingIndicator";

import { FiArrowDown } from "react-icons/fi";

export default function ChatWindow({
  messages = [],
  isThinking = false,
}) {

  const chatRef = useRef(null);
  const bottomRef = useRef(null);

  const [showScrollBtn, setShowScrollBtn] = useState(false);

  /*
  =========================================================
  CHECK WHETHER USER IS ALREADY NEAR BOTTOM
  =========================================================
  */

  const isNearBottom = (threshold = 120) => {

    const chat = chatRef.current;

    if (!chat) return true;

    const distance =
      chat.scrollHeight -
      chat.scrollTop -
      chat.clientHeight;

    return distance <= threshold;
  };


  /*
  =========================================================
  SCROLL TO BOTTOM
  =========================================================
  */

  const scrollToBottom = (behavior = "smooth") => {

    const chat = chatRef.current;

    if (!chat) return;

    chat.scrollTo({
      top: chat.scrollHeight,
      behavior,
    });
  };


  /*
  =========================================================
  AUTO SCROLL
  =========================================================

  Only auto-scroll when user is already near bottom.

  This is IMPORTANT.

  Agar user manually upar scroll kar raha hai,
  AI response ke streaming chunks usko wapas bottom
  par force nahi karenge.
  */

  useEffect(() => {

    if (!messages.length && !isThinking) return;

    if (isNearBottom(180)) {

      /*
        Instant scrolling during streaming prevents
        dozens of smooth animations fighting each other.
      */

      requestAnimationFrame(() => {

        scrollToBottom("auto");

      });

    }

  }, [messages, isThinking]);


  /*
  =========================================================
  SCROLL EVENT
  =========================================================
  */

  useEffect(() => {

    const chat = chatRef.current;

    if (!chat) return;

    let ticking = false;

    const handleScroll = () => {

      if (ticking) return;

      ticking = true;

      requestAnimationFrame(() => {

        const distance =
          chat.scrollHeight -
          chat.scrollTop -
          chat.clientHeight;

        setShowScrollBtn(distance > 250);

        ticking = false;

      });

    };

    chat.addEventListener(
      "scroll",
      handleScroll,
      { passive: true }
    );

    /*
      Initial state
    */

    handleScroll();

    return () => {

      chat.removeEventListener(
        "scroll",
        handleScroll
      );

    };

  }, []);


  /*
  =========================================================
  MANUAL SCROLL BUTTON
  =========================================================
  */

  const handleScrollToBottom = () => {

    scrollToBottom("smooth");

  };


  /*
  =========================================================
  RENDER
  =========================================================
  */

  return (

    <div
      ref={chatRef}
      className="chatWindow"
    >

      {messages.map((message, index) => {

        const messageId =
          message.id ||
          `${message.role}-${index}`;

        const messageContent =
          message.message ??
          message.content ??
          "";

        return (

          <MessageBubble
            key={messageId}

            id={messageId}

            sender={
              message.sender ||
              (
                message.role === "assistant"
                  ? "ai"
                  : "user"
              )
            }

            message={messageContent}

            timestamp={message.timestamp}

            onRegenerate={() => {

              console.log(
                "Regenerate:",
                messageId
              );

            }}

            onDelete={() => {

              console.log(
                "Delete:",
                messageId
              );

            }}
          />

        );

      })}


      {/* =================================================
          THINKING INDICATOR
      ================================================= */}

      {isThinking && (

        <TypingIndicator />

      )}


      {/* =================================================
          BOTTOM ANCHOR
      ================================================= */}

      <div
        ref={bottomRef}
        className="chatBottomAnchor"
        aria-hidden="true"
      />


      {/* =================================================
          SCROLL TO BOTTOM BUTTON
      ================================================= */}

      {showScrollBtn && (

        <button
          type="button"
          className="scrollBottomBtn"
          onClick={handleScrollToBottom}
          aria-label="Scroll to bottom"
          title="Scroll to bottom"
        >

          <FiArrowDown size={18} />

        </button>

      )}

    </div>

  );

}