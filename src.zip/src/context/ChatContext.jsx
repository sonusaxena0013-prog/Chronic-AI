import {
    createContext,
    useContext,
    useEffect,
    useRef,
    useState,
} from "react";

import { supabase } from "../lib/supabase";
import { useAuth } from "./AuthContext";

const ChatContext = createContext(null);

export function ChatProvider({ children }) {

    /* =====================================================
       AUTH
    ===================================================== */

    const {
        user,
        loading: authLoading,
    } = useAuth();


    /* =====================================================
       STATE
    ===================================================== */

    const [chats, setChats] = useState([]);
    const [currentChatId, setCurrentChatId] =
        useState(null);

    const [loading, setLoading] = useState(true);


    /* =====================================================
       REFS
       Keep latest values available to async functions
    ===================================================== */

    const chatsRef = useRef([]);
    const currentChatIdRef = useRef(null);
    const userRef = useRef(null);


    useEffect(() => {
        chatsRef.current = chats;
    }, [chats]);


    useEffect(() => {
        currentChatIdRef.current =
            currentChatId;
    }, [currentChatId]);


    useEffect(() => {
        userRef.current = user;
    }, [user]);


    /* =====================================================
       LOAD CHATS
    ===================================================== */

    useEffect(() => {

        let mounted = true;

        async function loadChats() {

            if (authLoading) {
                return;
            }

            /* =============================================
               USER LOGGED OUT
            ============================================= */

            if (!user) {

                chatsRef.current = [];

                if (mounted) {
                    setChats([]);
                    setCurrentChatId(null);
                    setLoading(false);
                }

                return;
            }


            if (mounted) {
                setLoading(true);
            }


            /* =============================================
               FETCH USER CHATS
            ============================================= */

            const {
                data,
                error,
            } = await supabase
                .from("chats")
                .select("*")
                .eq("user_id", user.id)
                .order("created_at", {
                    ascending: false,
                });


            if (error) {

                console.error(
                    "Chat loading error:",
                    error
                );

                if (mounted) {
                    setChats([]);
                    setCurrentChatId(null);
                    setLoading(false);
                }

                return;
            }


            /* =============================================
               FORMAT
            ============================================= */

            const formattedChats =
                (data || []).map((chat) => ({
                    id: chat.id,

                    userId: chat.user_id,

                    title:
                        chat.title ||
                        "New Chat",

                    createdAt:
                        chat.created_at,

                    messages:
                        Array.isArray(chat.messages)
                            ? chat.messages
                            : [],
                }));


            chatsRef.current =
                formattedChats;


            if (mounted) {

                setChats(formattedChats);


                /*
                 * Restore first chat
                 */

                if (
                    formattedChats.length > 0
                ) {

                    setCurrentChatId(
                        formattedChats[0].id
                    );

                    currentChatIdRef.current =
                        formattedChats[0].id;

                } else {

                    setCurrentChatId(null);

                    currentChatIdRef.current =
                        null;
                }


                setLoading(false);
            }
        }


        loadChats();


        return () => {
            mounted = false;
        };

    }, [user, authLoading]);


    /* =====================================================
       CREATE CHAT
    ===================================================== */

    const createChat = async () => {

        const currentUser =
            userRef.current;


        if (!currentUser) {

            console.warn(
                "Cannot create chat: user not logged in."
            );

            return null;
        }


        const chatId =
            crypto.randomUUID();


        const now =
            new Date().toISOString();


        const newChat = {

            id: chatId,

            user_id:
                currentUser.id,

            title:
                "New Chat",

            created_at:
                now,

            messages: [],
        };


        /* =============================================
           SAVE TO SUPABASE
        ============================================= */

        const {
            error,
        } = await supabase
            .from("chats")
            .insert(newChat);


        if (error) {

            console.error(
                "Create chat error:",
                error
            );

            return null;
        }


        /* =============================================
           LOCAL CHAT
        ============================================= */

        const formattedChat = {

            id: chatId,

            userId:
                currentUser.id,

            title:
                "New Chat",

            createdAt:
                now,

            messages: [],
        };


        const updatedChats = [
            formattedChat,
            ...chatsRef.current,
        ];


        chatsRef.current =
            updatedChats;


        setChats(updatedChats);


        currentChatIdRef.current =
            chatId;

        setCurrentChatId(chatId);


        return chatId;
    };


    /* =====================================================
       SELECT CHAT
    ===================================================== */

    const selectChat = (id) => {

        if (!id) return;

        const exists =
            chatsRef.current.some(
                (chat) =>
                    chat.id === id
            );

        if (!exists) return;


        currentChatIdRef.current =
            id;

        setCurrentChatId(id);
    };


    /* =====================================================
       DELETE CHAT
    ===================================================== */

    const deleteChat = async (id) => {

        const currentUser =
            userRef.current;


        if (!currentUser || !id) {
            return;
        }


        const deletingCurrent =
            currentChatIdRef.current === id;


        /* =============================================
           DELETE DATABASE FIRST
        ============================================= */

        const {
            error,
        } = await supabase
            .from("chats")
            .delete()
            .eq("id", id)
            .eq("user_id", currentUser.id);


        if (error) {

            console.error(
                "Delete chat error:",
                error
            );

            return;
        }


        /* =============================================
           REMOVE LOCALLY IMMEDIATELY
        ============================================= */

        const updatedChats =
            chatsRef.current.filter(
                (chat) =>
                    chat.id !== id
            );


        chatsRef.current =
            updatedChats;


        setChats(updatedChats);


        /* =============================================
           CURRENT CHAT DELETED
        ============================================= */

        if (deletingCurrent) {

            const nextChat =
                updatedChats.length > 0
                    ? updatedChats[0]
                    : null;


            if (nextChat) {

                currentChatIdRef.current =
                    nextChat.id;

                setCurrentChatId(
                    nextChat.id
                );

            } else {

                currentChatIdRef.current =
                    null;

                setCurrentChatId(null);
            }
        }
    };


    /* =====================================================
       CLEAR ALL CHATS
    ===================================================== */

    const clearAllChats = async () => {

        const currentUser =
            userRef.current;


        if (!currentUser) return;


        const {
            error,
        } = await supabase
            .from("chats")
            .delete()
            .eq(
                "user_id",
                currentUser.id
            );


        if (error) {

            console.error(
                "Clear chats error:",
                error
            );

            return;
        }


        chatsRef.current = [];

        setChats([]);

        currentChatIdRef.current =
            null;

        setCurrentChatId(null);
    };


    /* =====================================================
       RENAME CHAT
    ===================================================== */

    const renameChat = async (
        id,
        title
    ) => {

        const currentUser =
            userRef.current;


        if (!currentUser || !id) {
            return;
        }


        const cleanTitle =
            String(title || "")
                .trim()
                .slice(0, 80);


        if (!cleanTitle) {
            return;
        }


        const {
            error,
        } = await supabase
            .from("chats")
            .update({
                title:
                    cleanTitle,
            })
            .eq("id", id)
            .eq(
                "user_id",
                currentUser.id
            );


        if (error) {

            console.error(
                "Rename chat error:",
                error
            );

            return;
        }


        const updatedChats =
            chatsRef.current.map(
                (chat) =>
                    chat.id === id
                        ? {
                            ...chat,
                            title:
                                cleanTitle,
                        }
                        : chat
            );


        chatsRef.current =
            updatedChats;

        setChats(updatedChats);
    };


    /* =====================================================
       ADD MESSAGE
    ===================================================== */

    const addMessage = async (
        chatId,
        message
    ) => {

        const currentUser =
            userRef.current;


        if (!currentUser || !chatId) {
            return false;
        }


        const existingChat =
            chatsRef.current.find(
                (chat) =>
                    chat.id === chatId
            );


        if (!existingChat) {

            console.warn(
                "Chat not found:",
                chatId
            );

            return false;
        }


        const newMessages = [
            ...(existingChat.messages || []),
            message,
        ];


        /* =============================================
           AUTO TITLE
        ============================================= */

        let title =
            existingChat.title ||
            "New Chat";


        const isUserMessage =
            message?.role === "user" ||
            message?.sender === "user";


        const messageText =
            message?.content ||
            message?.message ||
            message?.text ||
            "";


        if (
            title === "New Chat" &&
            isUserMessage &&
            messageText.trim()
        ) {

            /*
             * Short title.
             * This prevents sidebar from becoming huge.
             */

            const firstLine =
                messageText
                    .replace(/\s+/g, " ")
                    .trim();


            title =
                firstLine.length > 42
                    ? firstLine.slice(0, 42) +
                      "..."
                    : firstLine;
        }


        const updatedChat = {
            ...existingChat,
            title,
            messages:
                newMessages,
        };


        /* =============================================
           LOCAL UPDATE FIRST
        ============================================= */

        const updatedChats =
            chatsRef.current.map(
                (chat) =>
                    chat.id === chatId
                        ? updatedChat
                        : chat
            );


        chatsRef.current =
            updatedChats;

        setChats(updatedChats);


        /* =============================================
           SUPABASE
        ============================================= */

        const {
            error,
        } = await supabase
            .from("chats")
            .update({
                title,
                messages:
                    newMessages,
            })
            .eq(
                "id",
                chatId
            )
            .eq(
                "user_id",
                currentUser.id
            );


        if (error) {

            console.error(
                "Add message save error:",
                error
            );

            return false;
        }


        return true;
    };


    /* =====================================================
       UPSERT STREAMING MESSAGE
    ===================================================== */

    const upsertMessage = async (
        chatId,
        messageId,
        message
    ) => {

        const currentUser =
            userRef.current;


        if (
            !currentUser ||
            !chatId ||
            !messageId
        ) {
            return false;
        }


        const existingChat =
            chatsRef.current.find(
                (chat) =>
                    chat.id === chatId
            );


        /*
         * Important:
         * If chat was deleted while AI was streaming,
         * ignore remaining chunks.
         */

        if (!existingChat) {
            return false;
        }


        const oldMessages = [
            ...(existingChat.messages || []),
        ];


        const index =
            oldMessages.findIndex(
                (msg) =>
                    msg.id ===
                    messageId
            );


        let newMessages;


        if (index === -1) {

            newMessages = [
                ...oldMessages,
                message,
            ];

        } else {

            newMessages = [
                ...oldMessages,
            ];

            newMessages[index] =
                message;
        }


        /* =============================================
           LOCAL UPDATE
        ============================================= */

        const updatedChats =
            chatsRef.current.map(
                (chat) =>
                    chat.id === chatId
                        ? {
                            ...chat,
                            messages:
                                newMessages,
                        }
                        : chat
            );


        chatsRef.current =
            updatedChats;

        setChats(updatedChats);


        /* =============================================
           SAVE
        ============================================= */

        const {
            error,
        } = await supabase
            .from("chats")
            .update({
                messages:
                    newMessages,
            })
            .eq(
                "id",
                chatId
            )
            .eq(
                "user_id",
                currentUser.id
            );


        if (error) {

            console.error(
                "Streaming save error:",
                error
            );

            return false;
        }


        return true;
    };


    /* =====================================================
       REPLACE ALL MESSAGES
    ===================================================== */

    const setMessages = async (
        chatId,
        messages
    ) => {

        const currentUser =
            userRef.current;


        if (!currentUser || !chatId) {
            return;
        }


        const existingChat =
            chatsRef.current.find(
                (chat) =>
                    chat.id === chatId
            );


        if (!existingChat) {
            return;
        }


        const updatedChats =
            chatsRef.current.map(
                (chat) =>
                    chat.id === chatId
                        ? {
                            ...chat,
                            messages,
                        }
                        : chat
            );


        chatsRef.current =
            updatedChats;

        setChats(updatedChats);


        const {
            error,
        } = await supabase
            .from("chats")
            .update({
                messages,
            })
            .eq(
                "id",
                chatId
            )
            .eq(
                "user_id",
                currentUser.id
            );


        if (error) {

            console.error(
                "Set messages error:",
                error
            );
        }
    };


    /* =====================================================
       CURRENT CHAT
    ===================================================== */

    const currentChat =
        chats.find(
            (chat) =>
                chat.id ===
                currentChatId
        ) || null;


    /* =====================================================
       PROVIDER
    ===================================================== */

    return (

        <ChatContext.Provider
            value={{

                chats,

                setChats,

                currentChat,

                currentChatId,

                setCurrentChatId:
                    selectChat,

                createChat,

                deleteChat,

                clearAllChats,

                renameChat,

                addMessage,

                upsertMessage,

                setMessages,

                loading,
            }}
        >

            {children}

        </ChatContext.Provider>
    );
}


/* =====================================================
   HOOK
===================================================== */

export function useChats() {

    return useContext(
        ChatContext
    );
}